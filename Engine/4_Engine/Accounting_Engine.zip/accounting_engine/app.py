"""Accounting Engine – bill photo / voice -> Tally ledger Excel.

Run:  streamlit run app.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

from engine import bank, config, db  # noqa: E402
from ui import bank_slips, bills, masters, new_bill, settings  # noqa: E402

st.set_page_config(page_title=f"{config.BUSINESS_NAME} · Bills → Tally", page_icon="🧾", layout="wide")


# Cheap (CREATE TABLE IF NOT EXISTS) – run every time so a deleted/restored database file
# is always usable without restarting the app.
db.init_db()
bank.init()

PAGES = {
    "📄 New Bill": new_bill.render,
    "🏦 Bank Slips": bank_slips.render,
    "📚 Bills & Export": bills.render,
    "👥 Parties": masters.render_parties,
    "📦 Items": masters.render_items,
    "⚙️ Settings & Import": settings.render,
}

with st.sidebar:
    st.markdown(f"## 🧾 {config.BUSINESS_NAME}")
    page = st.radio("Go to", list(PAGES), label_visibility="collapsed", key="nav")
    s = db.stats()
    st.caption(f"{s['parties']} parties · {s['bills']} bills · {s['unexported']} awaiting export")
    st.caption(f"Reader: {config.EXTRACTOR_MODE} · {config.CLAUDE_MODEL}")

PAGES[page]()
