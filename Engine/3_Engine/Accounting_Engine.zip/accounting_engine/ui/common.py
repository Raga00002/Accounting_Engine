"""Shared UI helpers."""
from __future__ import annotations

import math
from typing import Any, Optional

import pandas as pd
import streamlit as st

from engine.models import LineItem

ITEM_COLS = ["item", "qty", "unit", "weight_qtl", "rate", "amount", "struck_out", "note"]

ITEM_COLUMN_CONFIG = {
    "item": st.column_config.TextColumn("Item", required=True, width="medium"),
    "qty": st.column_config.NumberColumn("Qty", min_value=0, step=1, format="%g"),
    "unit": st.column_config.SelectboxColumn("Unit", options=["Bag", "Pkt", "Tin", "Kg", "Ltr", "Qtl", "Pcs", "Box"], width="small"),
    "weight_qtl": st.column_config.NumberColumn("Weight (Qtl)", min_value=0, step=0.01, format="%.2f"),
    "rate": st.column_config.NumberColumn("Rate ₹", min_value=0, step=1, format="%.2f"),
    "amount": st.column_config.NumberColumn("Amount ₹", min_value=0, step=1, format="%.2f",
                                            help="Leave blank to auto-calculate (weight × rate, else qty × rate)"),
    "struck_out": st.column_config.CheckboxColumn("Struck", help="Line crossed out on the bill – excluded from total"),
    "note": st.column_config.TextColumn("Note", width="medium"),
}


_NUM_COLS = ("qty", "weight_qtl", "rate", "amount")
_TEXT_COLS = ("item", "unit", "note")


def items_to_df(items: list[LineItem]) -> pd.DataFrame:
    rows = [it.model_dump() for it in items]
    df = pd.DataFrame(rows, columns=ITEM_COLS)
    # Explicit dtypes: an empty frame would otherwise get int64 number columns (a decimal weight
    # typed into the editor could then not be stored) and object text columns.
    for c in _TEXT_COLS:
        df[c] = df[c].astype(object).where(df[c].notna(), None)
    df["struck_out"] = df["struck_out"].fillna(False).astype(bool)
    for c in _NUM_COLS:
        df[c] = pd.to_numeric(df[c], errors="coerce").astype("float64")
    return df


def _missing(v: Any) -> bool:
    if v is None:
        return True
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def _clean(v: Any) -> Optional[float]:
    if _missing(v):
        return None
    try:
        if isinstance(v, str):
            v = v.strip().replace(",", "")
            if not v:
                return None
        f = float(v)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(f) else f


def _clean_text(v: Any) -> Optional[str]:
    if _missing(v):
        return None
    s = str(v).strip()
    return s if s and s.lower() not in ("nan", "none", "<na>") else None


def _clean_bool(v: Any) -> bool:
    if _missing(v):
        return False
    if isinstance(v, str):
        return v.strip().lower() in ("true", "1", "yes")
    try:
        return bool(v)
    except (TypeError, ValueError):
        return False


def df_to_items(df: pd.DataFrame) -> list[LineItem]:
    items: list[LineItem] = []
    for _, r in df.iterrows():
        name = _clean_text(r.get("item"))
        if not name:
            continue
        items.append(
            LineItem(
                item=name,
                qty=_clean(r.get("qty")),
                unit=_clean_text(r.get("unit")),
                weight_qtl=_clean(r.get("weight_qtl")),
                rate=_clean(r.get("rate")),
                amount=_clean(r.get("amount")),
                struck_out=_clean_bool(r.get("struck_out")),
                note=_clean_text(r.get("note")),
            )
        )
    return items


def money(v: Optional[float]) -> str:
    if v is None:
        return "—"
    return f"₹ {v:,.2f}"


def toast_ok(msg: str) -> None:
    try:
        st.toast(msg, icon="✅")
    except Exception:  # pragma: no cover
        st.success(msg)
