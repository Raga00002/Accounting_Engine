"""Bills & Export page: browse saved bills, build the Tally Excel, delete mistakes."""
from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

import pandas as pd
import streamlit as st

from engine import config, db, exporter
from ui.common import money, toast_ok


def _filters():
    c1, c2, c3, c4 = st.columns([1, 1, 2, 1])
    today = date.today()
    fy_start = date(today.year if today.month >= 4 else today.year - 1, 4, 1)
    dfrom = c1.date_input("From", value=fy_start, key="bx_from", format="DD/MM/YYYY")
    dto = c2.date_input("To", value=today, key="bx_to", format="DD/MM/YYYY")
    parties = db.list_parties()
    by_id = {p.id: p for p in parties}  # dict lookup: 8,000 ledgers x 8,000 options otherwise
    pid = c3.selectbox("Party", [None, *by_id], key="bx_party",
                       format_func=lambda i: "All parties" if i is None else by_id[i].name if i in by_id else str(i))
    if pid is not None and pid not in by_id:
        pid = None  # stale selection (party deleted / database restored) -> all parties
    only_new = c4.toggle("Only not-yet-exported", value=True, key="bx_only_new")
    if dfrom > dto:
        st.error("'From' date is after 'To' date.")
    return dfrom, dto, pid, only_new, by_id


def _last_export_section() -> None:
    if st.session_state.get("bx_last_export"):
        fname, data, n, path = st.session_state["bx_last_export"]
        st.download_button(f"⬇️ Download {fname} ({n} bills)", data=data, file_name=fname,
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", key="bx_dl")
        st.caption(f"Also saved to `{path}`. In Tally Prime: Gateway of Tally → Import → Masters → Ledgers → select this file.")


def render() -> None:
    st.title("📚 Bills & Export")
    dfrom, dto, pid, only_new, parties = _filters()
    bills = db.list_bills(party_id=pid, date_from=dfrom, date_to=dto, exported=False if only_new else None, with_items=True)

    if not bills:
        st.info("No bills match these filters.")
        _last_export_section()  # the file just built must stay downloadable after its bills were marked
        return

    rows = []
    for b in bills:
        p = parties.get(b.party_id)
        rows.append({
            "Export": True, "ID": b.id, "Date": b.bill_date, "Bill No": b.bill_no,
            "Party": p.name if p else f"#{b.party_id}", "Amount": b.amount, "Dr/Cr": b.drcr, "Type": b.txn_type,
            "Items": len(b.items), "Source": b.source, "Exported": "✓" if b.exported else "",
        })
    df = pd.DataFrame(rows)
    # Key includes the exact set of bills shown: the editor's tick/untick state is otherwise
    # applied by row position and would carry over to a different list with the same length.
    table_key = f"bx_table_{hash(tuple(b.id for b in bills))}"
    edited = st.data_editor(
        df, hide_index=True, width="stretch", key=table_key,
        disabled=[c for c in df.columns if c != "Export"],
        column_config={
            "Export": st.column_config.CheckboxColumn("Export"),
            "Date": st.column_config.DateColumn("Date", format="DD/MM/YYYY"),
            "Amount": st.column_config.NumberColumn("Amount ₹", format="%.2f"),
        },
    )
    selected_ids = [int(i) for i in edited.loc[edited["Export"] == True, "ID"].tolist()]  # noqa: E712
    total = sum(b.amount for b in bills if b.id in selected_ids)
    st.caption(f"{len(selected_ids)} of {len(bills)} bill(s) selected · total {money(total)}")

    st.subheader("Export to Tally")
    o1, o2, o3, o4 = st.columns(4)
    inc_ob = o1.checkbox("Include opening balances", value=True, key="bx_ob",
                         help="Untick if these ledgers already exist in Tally with balances.")
    inc_addr = o2.checkbox("Include address / state / pincode", value=True, key="bx_addr")
    inc_items = o3.checkbox("Add 'Items' sheet", value=True, key="bx_items")
    mark = o4.checkbox("Mark as exported when the file is built", value=True, key="bx_mark",
                       help="The file is also saved in the exports folder, so it is safe to mark at build time.")

    if st.button("📥 Build Excel file", type="primary", disabled=not selected_ids, key="bx_build"):
        fname = exporter.default_export_name()
        out = config.EXPORT_DIR / fname
        try:
            data, ids = exporter.export_bills(
                bill_ids=selected_ids, include_opening_balance=inc_ob, include_address=inc_addr,
                include_items_sheet=inc_items, mark_exported=mark, out_path=out,
            )
        except Exception as e:  # noqa: BLE001 - e.g. exports folder not writable
            st.error(f"Could not build the Excel file: {e}")
        else:
            st.session_state["bx_last_export"] = (fname, data, len(ids), str(out))
            toast_ok(f"Built {fname} with {len(ids)} bill(s).")
            if mark and ids:
                st.rerun()  # refresh the list (marked bills drop out of 'not-yet-exported')
    _last_export_section()

    st.subheader("Bill details / delete")
    bills_by_id = {b.id: b for b in bills}
    bill_labels = {b.id: f"{b.bill_date:%d/%m/%Y} · {b.bill_no} · {parties[b.party_id].name if b.party_id in parties else ''} · {money(b.amount)}"
                   for b in bills}
    bid = st.selectbox("Bill", list(bills_by_id), key="bx_detail", format_func=lambda i: bill_labels.get(i, str(i)))
    if bid not in bills_by_id:
        bid = bills[0].id  # stale selection after the filters changed
    b = bills_by_id[bid]
    l, r = st.columns([3, 2])
    with l:
        if b.items:
            idf = pd.DataFrame([i.model_dump() for i in b.items])
            idf["amount"] = [i.effective_amount for i in b.items]
            st.dataframe(idf[["item", "qty", "unit", "weight_qtl", "rate", "amount", "struck_out"]], hide_index=True, width="stretch")
        else:
            st.caption("No line items recorded for this bill.")
        if b.total_written is not None:
            st.caption(f"Total written on bill: {money(b.total_written)} · booked: {money(b.amount)}")
        if b.raw_text:
            with st.expander("Raw transcription"):
                st.code(b.raw_text)
        confirm = st.checkbox("I want to delete this bill", key=f"bx_del_confirm_{bid}")
        if st.button("🗑️ Delete bill", disabled=not confirm, key=f"bx_del_{bid}"):
            try:
                db.delete_bill(bid)
            except Exception as e:  # noqa: BLE001
                st.error(f"Could not delete: {e}")
            else:
                toast_ok("Bill deleted.")
                st.rerun()
    with r:
        if b.image_path and Path(b.image_path).exists():
            if b.image_path.lower().endswith(".pdf"):
                st.caption(f"PDF stored at {b.image_path}")
            else:
                try:
                    st.image(b.image_path, width="stretch")
                except Exception:  # noqa: BLE001
                    st.caption(f"Image stored at {b.image_path} (preview not available)")
        else:
            st.caption("No image stored for this bill.")
