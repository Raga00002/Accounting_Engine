# Accounting Engine — bill photo / voice → Tally ledger Excel

A local web app for **Wings Industries**: photograph (or dictate) a handwritten kachha bill,
let Claude read it, confirm the party and any missing details, and get an Excel file in
Tally Prime's **"Ledgers in Default Template"** layout — plus a party/item database that
learns as you go.

```
photo / voice / typed text
        │
        ▼
 Claude extraction  ──►  party fuzzy-match against DB  ──►  review screen
 (items, qty, weight,     (auto / confirm / add new,         (fix anything, add date &
  rate, amount, total)     alias remembered)                  bill no., arithmetic checks)
        │                                                             │
        ▼                                                             ▼
   SQLite database  (parties · bills · line items · items master)   Save
        │
        ▼
 Excel export: sheet "Ledger" (exact Tally template) + sheet "Items" (line items)
```

## 1 · Install (Windows)

1. Install **Python 3.11 or newer** from python.org (tick *"Add python.exe to PATH"*).
2. Unzip / copy this folder anywhere, e.g. `Documents\Accounting_Engine`.
3. Double-click **`run.bat`**. The first run creates a virtual environment, installs the
   packages and opens `.env` in Notepad.
4. Paste your Anthropic API key into `.env`:
   ```
   ANTHROPIC_API_KEY=sk-ant-...
   AE_EXTRACTOR_MODE=live
   ```
   (keys: <https://console.anthropic.com>). Save, close Notepad, double-click `run.bat` again.
5. The app opens in your browser at <http://localhost:8501>. Phones on the same Wi-Fi can use
   the *Network URL* printed in the black window (camera + mic need Chrome/Edge; on a phone
   allow the browser to use the camera).

## 1b · Install on Ubuntu Linux (x86_64 **or aarch64 / ARM64** – Raspberry Pi, ARM servers, Ampere, Apple-silicon VMs)

Every dependency ships prebuilt `aarch64` wheels (verified for Python 3.10 and 3.12), so nothing is compiled.

```bash
sudo apt update && sudo apt install -y python3 python3-venv python3-pip openssl   # flac only for .flac uploads
unzip Accounting_Engine.zip && cd Accounting_Engine        # or: cd ~/Documents/Accounting_Engine
chmod +x run.sh
./run.sh            # 1st run: creates .venv, installs packages, creates .env and stops
nano .env           # paste ANTHROPIC_API_KEY=sk-ant-...   (keep AE_EXTRACTOR_MODE=live)
./run.sh            # starts the server
```

`run.sh` prints two addresses:

| Open from | URL | Camera / mic |
|---|---|---|
| a browser on the Ubuntu machine itself | `http://localhost:8501` | works |
| a phone/laptop on the same network | `http://<ubuntu-ip>:8501` | **blocked by the browser** on plain http |
| a phone/laptop, started with `AE_HTTPS=1 ./run.sh` | `https://<ubuntu-ip>:8501` | works (accept the self-signed certificate once) |

Useful variants: `AE_PORT=8600 ./run.sh` (other port) · `./run.sh --check` (verify install only) ·
`AE_ADDRESS=127.0.0.1 ./run.sh` (local only). The Excel files are also written to `data/exports/`
on the Ubuntu machine, so on a headless box you can `scp` them if you prefer.

**Run at boot (systemd):** `deploy/accounting-engine.service` – edit `User=`/`WorkingDirectory=`, then
`sudo cp deploy/accounting-engine.service /etc/systemd/system/ && sudo systemctl enable --now accounting-engine`.

**Docker (multi-arch, amd64 + arm64):** `docker compose up -d --build` (uses `.env`, keeps `data/` on the host).
The image was not built in this environment – it follows the standard `python:3.12-slim` pattern.

Mac: `./run.sh` works the same way.

## 2 · First-time setup inside the app — load your Tally masters

**⚙️ Settings & Import → Import parties & items from Tally.** Export from Tally Prime and upload the file;
the app detects the report type, shows a preview, and you confirm before anything is written.

| Tally export | Path in Tally | Formats accepted | What is imported |
|---|---|---|---|
| **List of Ledgers** (`Master.pdf`) | Gateway → Display More Reports → List of Accounts → Ledgers → Export (or Alt+E) | PDF, Excel (.xlsx), CSV, or the PDF's text (.txt) | Ledger name, group (*Under*), opening balance Dr/Cr. Names that wrap onto two lines, serial numbers with commas and user-defined groups (e.g. *GEM*, *Govt. Debtors*, sub-groups) are handled. You tick which groups are parties — debtor/creditor-type groups are pre-ticked, expense/bank/tax ledgers are not. |
| **Stock Summary** (`StkSum.xlsx`) | Gateway → Stock Summary → Export | Excel (.xlsx), CSV | Item name, stock group, unit (read from Tally's number format, e.g. *Pcs*), last rate. Group rows, godown rows and *Grand Total* are skipped. |
| **Ledgers in Default Template** | Import-format workbook | Excel | Parties with address/state/pincode and open bills (marked *exported*). |

Re-importing is safe: existing parties/items are updated (group, opening balance, unit, rate) — aliases,
addresses and bills you added in the app are kept. Tested with a 7,879-ledger list (≈4 s) and a
715-item stock summary.

## 3 · Daily use

### 📄 New Bill
| Tab | What to do |
|---|---|
| **📷 Photo / Upload** | Upload one or many bill photos (JPG/PNG/WEBP/PDF) or toggle *Use camera*. Click **Read this bill**. |
| **🎤 Voice** | Pick the language (English-India, Hindi, Assamese, Bengali), press *Start recording*, dictate, press *Stop*. Check the transcript, click **Parse transcript**. You can also upload a WAV file. |
| **⌨️ Type / Manual** | Type the bill in plain words, or start a blank bill and fill the table by hand. |

Then the **review screen**:

1. **Party check** – the name on the bill is looked up in the party master first:
   *Matched ✅* (exact or safe variant: case, "Stores/Store", "M/S", initials) · *confirm ❓* (close
   spellings listed with match %, e.g. "Gotam Kotna" → "Gautam Kotna"; numbered units like
   "20 Bn BSF" vs "200 Bn BSF" are never auto-matched) · *not in database 🆕* → fill group/address once,
   it is added on save and the bill's spelling is remembered as an alias.
2. **Bill details** – date (defaults to today if not on the bill – confirm), bill number (type it
   or *Auto-number* → `WI/2026-27/001`), Sale (Dr) / Purchase (Cr).
3. **Items** – editable table: item, qty, unit, weight (quintal), rate, amount, struck-out, note.
   Blank amount = weight × rate (or qty × rate). Crossed-out lines stay visible but are excluded.
3b. **Item check** – every description is checked against the items master:
   *Known ✅* (exact, case/punctuation variants, initials such as "Rice RR" → "Rice (R.R)"; never across
   different numbers or words — "Rice (R.R 10)" is not "Rice (R.R)") · otherwise a box per item where you
   choose **Use existing: …** (close matches with %), **➕ Add as NEW item** (name, unit, stock group) or
   **🔍 Use another existing item**. **Save stays disabled until every unknown item has a decision**; new
   items are created only then, and the bill's spelling is stored as an alias for next time.
4. **Totals & checks** – sum of lines vs total written on the bill; mismatches and missing data are
   flagged. Choose which amount to book if they differ. **Save bill**.

### 📚 Bills & Export
Filter by date / party / not-yet-exported, tick the bills, choose options
(opening balances, addresses, Items sheet, mark as exported) → **Build Excel file** → download.
The file is also saved under `data/exports/`.

**In Tally Prime:** Gateway of Tally → Import → Masters → *Ledgers* → choose the downloaded file
(Excel format, default template). Untick *Include opening balances* if the ledgers already exist
in Tally with balances.

### 👥 Parties · 📦 Items
Edit names, groups, addresses, opening balances and aliases; merge spellings via aliases.

## 4 · Where things live

| | |
|---|---|
| Database | `data/accounting.db` (SQLite – back it up from Settings) |
| Bill images | `data/bill_images/` |
| Excel exports | `data/exports/` |
| Settings | `.env` (see `.env.example`: business name, default state, bill prefix, model, data folder) |
| HTTPS certificate (Linux, `AE_HTTPS=1`) | `certs/` |

## 5 · Reading conventions Claude is told about

* `5 Bg Rice (BPT) 5 x 1540 7700` → 5 bags priced per bag.
* `2 Bg Rice (Sri) .52 x 5550 2886` → 2 bags, 0.52 quintal × ₹5550/qtl.
* Struck lines are listed with *Struck* ticked and excluded from the total.
* The small printed page number (13, 32, 02 …) is **not** used as the bill number.
* Dates are never guessed – you are asked.
* Known party and item spellings from your database are passed to Claude so it prefers them.

## 6 · Development

```
pip install -r requirements.txt
python -m pytest -q tests          # 66 tests (DB, importers incl. Tally PDF/xlsx, matcher, validator, extractor, exporter, speech)
AE_EXTRACTOR_MODE=mock streamlit run app.py   # offline demo: sample bills return canned readings
```

Layout: `engine/` (pure logic, no Streamlit) · `ui/` (pages) · `app.py` (navigation) ·
`fixtures/` (Tally template, 5 sample bills, mock extractions, sample Tally *List of Ledgers* / *Stock Summary* exports used by the tests) · `tests/`.
See `ROADMAP.md` for the build plan, decisions and what is next.
