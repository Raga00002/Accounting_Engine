# Accounting Engine — development roadmap & decision log

## Decisions taken (26 Sep 2026)

| Question | Decision |
|---|---|
| AI backend for handwriting + dictation | Anthropic Claude API (vision + text, forced tool-use JSON). Speech-to-text: browser mic → Google free web-speech via `SpeechRecognition` (no key). |
| Output | Sheet **Ledger** = exact Tally "Ledgers in Default Template" (party block, continuation rows) + sheet **Items** with line items. |
| Missing bill date / number | Never guessed – the review screen asks (date defaults to today, *Auto-number* available). Printed page numbers on the bill book are ignored. |
| Platform | Local Streamlit web app on the Windows laptop, SQLite database, usable from phones on the same Wi-Fi. **Also runs on Ubuntu Linux x86_64 / aarch64** (`run.sh`, systemd unit, multi-arch Dockerfile); optional self-signed HTTPS so phone camera/mic work over the LAN. |
| Default state / country / group | Assam / India / Sundry Debtors (sale) – Sundry Creditors (purchase). Editable in `.env`. |
| Amount to book | Sum of line amounts (written or computed) by default; user can choose the written total when they differ. |

## Phases (all complete)

| # | Phase | Verification |
|---|---|---|
| 1 | Scaffold, pydantic models, SQLite schema, Tally template importer | 4 tests: upsert/alias, bill round-trip, items master, import of template (15 ledgers, 4 bills, idempotent) |
| 2 | Party/item fuzzy matcher, arithmetic validator | tests on 5 sample parties, spelling variants, false-positive guards, struck-out lines, mismatch warnings |
| 3 | Claude extractor (image, PDF, text) with offline mock mode | tests with fake SDK client (model fallback, truncation), image downsizing/EXIF/media types, messy model output |
| 4 | Tally Excel exporter | layout compared cell-by-cell with the template; export → import round trip |
| 5 | Streamlit UI (5 pages) | Playwright end-to-end: import → read sample bill → new party → save → auto-match → auto-number → export → masters |
| 6 | QA audit agent + independent re-audit agent | 17 findings fixed (data-editor edit loss, matcher false positives, upload queue, image/media handling, stereo WAV, backup/restore safety, run.bat…); 45 tests green |
| 7 | Packaging: README, run.bat/run.sh, .env.example, delivery | this document |
| 9 | Tally master import (List of Ledgers PDF/xlsx/csv/txt with learned custom groups; Stock Summary xlsx with units from number formats), party-first check and **item check with explicit confirmation** before new items are created; `pypdf` layout-mode extraction | 66 tests incl. real 7,879-ledger / 715-item exports; Playwright e2e (`probe_tally.py`); QA audit (12 fixes) + independent re-audit (numbered-unit party rule, initials in item names, godown heuristic, 3 perf fixes) |
| 8 | Linux / ARM64 support: hardened `run.sh` (venv, headless, LAN address, port, `--check`, self-signed HTTPS), `Dockerfile` + `docker-compose.yml` (amd64/arm64), `deploy/accounting-engine.service` | aarch64 wheel availability verified with `pip download --platform manylinux_2_28_aarch64` for py3.10/3.12; `run.sh` exercised end-to-end on Linux incl. HTTPS + Playwright page check |

## Architecture

```
app.py                 navigation, DB bootstrap
ui/new_bill.py         capture → extract → review → save
ui/bills.py            browse, export, delete
ui/masters.py          parties & items
ui/settings.py         stats, Tally import, backup/restore
ui/common.py           items table <-> pydantic helpers
engine/config.py       .env driven settings
engine/models.py       LineItem, BillDraft, Party, Bill, ValidationReport
engine/db.py           SQLite (parties, bills, bill_items, items, settings), WAL, per-call connections
engine/importer.py     Tally template → DB
engine/matcher.py      rapidfuzz party/item matching: noise/type words, initials, digit-token rule (never auto-match across numbers)
engine/tally_import.py Tally 'List of Ledgers' (PDF/xlsx/csv/txt) & 'Stock Summary' (xlsx/csv) parsers + apply to DB
engine/validator.py    fill missing amounts, arithmetic checks, missing-field list
engine/extractor.py    Claude vision/text → BillDraft (tool schema, prompt with trade conventions, mock mode)
engine/exporter.py     Tally workbook (starts from the template file to keep styling) + Items sheet
engine/service.py      use-cases: resolve party, commit bill (party + alias + image + bill)
engine/speech.py       WAV → text
```

## Next steps (not built yet – pick what you need)

1. **Live-API acceptance run** on the 5 real photos with your key; tune `SYSTEM_PROMPT` wording
   for any systematic misreads (e.g. variety abbreviations).
2. **Voucher export** (Sales/Purchase vouchers with stock items) in addition to ledgers – Tally's
   voucher template or XML, so line items post to inventory.
3. **GST fields** (GSTIN, tax ledgers) on parties and bills if you move from kachha to pakka bills.
4. **Multi-user / hosted** deployment (Streamlit Community Cloud or a small VPS) with a login,
   if staff should enter bills from anywhere.
5. **Outstanding & receipts**: record payments against bills and export receipt vouchers.
6. **Packaging as .exe** (PyInstaller) for machines without Python.
7. **Proper TLS certificate** (Let's Encrypt / Tailscale) instead of the self-signed one if the Ubuntu box gets a hostname.

## Known limits

* Ledger-list parsing separates *Name* from *Under* by text alone; a custom group whose name ends in a default group name (e.g. "HDFC Bank Accounts") is split wrongly – check the preview's *Examples* column and correct the group on the Parties page.
* Stock Summary godown rows are detected by repetition; a genuine item directly following another with identical qty/rate/value is listed under *Skipped lines* in the preview.

* Handwriting accuracy depends on the photo – flat, well-lit, whole bill in frame.
* Voice recognition uses Google's free endpoint (needs internet); Assamese/Bengali quality varies.
* `Auto-number` consumes a sequence number even if the bill is then discarded (gaps possible).
* Keep `data/` on a local disk (not OneDrive-synced) – SQLite WAL and sync clients don't mix.
