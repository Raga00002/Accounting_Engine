"""Settings & Import page."""
from __future__ import annotations

import sqlite3
from datetime import datetime

import streamlit as st

from engine import config, db
from engine import tally_export, tally_import as ti
from engine.importer import import_ledger_template
from ui.common import toast_ok


def render() -> None:
    st.title("⚙️ Settings & Import")

    s = db.stats()
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Parties", s["parties"])
    c2.metric("Bills", s["bills"])
    c3.metric("Not exported", s["unexported"])
    c4.metric("Items", s["items"])

    st.subheader("AI reader")
    key_ok = bool(config.ANTHROPIC_API_KEY)
    st.markdown(
        f"- Mode: **{config.EXTRACTOR_MODE}**\n"
        f"- Model: `{config.CLAUDE_MODEL}` (fallbacks: {', '.join(config.CLAUDE_FALLBACK_MODELS)})\n"
        f"- API key: {'✅ set (…' + config.ANTHROPIC_API_KEY[-4:] + ')' if key_ok else '❌ missing'}\n"
        f"- Database: `{config.DB_PATH}`\n"
        f"- Bill images: `{config.BILL_IMAGE_DIR}` · Exports: `{config.EXPORT_DIR}`"
    )
    st.caption("Change these in the `.env` file next to app.py and restart the app.")

    _import_section()
    _tally_settings_section()

    st.subheader("Backup")
    if config.DB_PATH.exists():
        # SQLite's backup API – a plain file copy can miss data still in the -wal file.
        try:
            st.download_button("⬇️ Download database backup (.db)", data=db.backup_bytes(),
                               file_name=f"accounting_{datetime.now():%Y%m%d_%H%M}.db", key="st_backup")
        except Exception as e:  # noqa: BLE001
            st.error(f"Backup not available: {e}")
    restore = st.file_uploader("Restore database from a backup (.db) – replaces current data!", type=["db"], key="st_restore")
    if restore is not None:
        sure = st.checkbox("Yes, replace the current database with this backup", key="st_restore_sure")
        if st.button("♻️ Restore", disabled=not sure, key="st_do_restore"):
            data = restore.getvalue()
            if data[:16] != b"SQLite format 3\x00":
                st.error("That file is not a SQLite database.")
            else:
                try:
                    _restore_database(data)
                except Exception as e:  # noqa: BLE001
                    st.error(f"Restore failed – the current database was left unchanged: {e}")
                else:
                    st.rerun()


def _restore_database(data: bytes) -> None:
    """Replace the live database with ``data`` after validating it, keeping a backup of the old one."""
    # 1. Validate the upload on a scratch copy before touching anything.
    scratch = config.DB_PATH.with_name(f".restore_check_{datetime.now():%Y%m%d_%H%M%S}.db")
    scratch.write_bytes(data)
    try:
        chk = sqlite3.connect(str(scratch))
        try:
            if chk.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("the backup file is corrupt (integrity check failed)")
            tables = {r[0] for r in chk.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not {"parties", "bills"} <= tables:
                raise ValueError("the file is a SQLite database but not an Accounting Engine backup")
        finally:
            chk.close()  # Windows: the file cannot be deleted while a connection holds it
    finally:
        try:
            scratch.unlink()
        except OSError:
            pass
    # 2. Keep the current database (WAL content included).
    bak = None
    if config.DB_PATH.exists():
        bak = config.DB_PATH.with_name(f"{config.DB_PATH.stem}.before_restore_{datetime.now():%Y%m%d_%H%M%S}.db")
        db.backup_to(bak)
    # 3. Swap. Stale -wal/-shm files belong to the old database and must go first.
    for suffix in ("-wal", "-shm"):
        p = config.DB_PATH.with_name(config.DB_PATH.name + suffix)
        if p.exists():
            p.unlink()
    config.DB_PATH.write_bytes(data)
    db.init_db()
    toast_ok("Restored." + (f" Previous database kept at {bak.name}" if bak else ""))


# --------------------------------------------------------------------------- #
# Tally master import wizard: upload -> preview (choose groups) -> import
# --------------------------------------------------------------------------- #
def _import_section() -> None:
    st.subheader("Import parties & items from Tally")
    st.markdown(
        "Export from Tally and upload here – the format is detected automatically:\n"
        "- **Parties:** *Display → List of Accounts → Ledgers* exported as **PDF / Excel / CSV / TXT**, "
        "or the *Ledgers in Default Template* workbook.\n"
        "- **Items:** *Stock Summary* exported as **Excel**, or any Excel/CSV list with an *Item / Name* column.\n"
        "Existing parties and items are updated, never duplicated."
    )
    up = st.file_uploader("Tally export file", type=["pdf", "xlsx", "csv", "txt"], key="st_tally_file")
    ss = st.session_state
    fp = (up.name, up.size, getattr(up, "file_id", None)) if up is not None else None
    if fp != ss.get("st_tally_fp"):
        ss["st_tally_fp"] = fp
        ss.pop("st_tally_preview", None)
    c1, c2 = st.columns(2)
    if c1.button("🔍 Read file", type="primary", disabled=up is None, key="st_tally_read"):
        try:
            with st.spinner("Reading…"):
                ss["st_tally_preview"] = ti.detect_and_parse(up.getvalue(), up.name)
        except Exception as e:  # noqa: BLE001
            st.error(f"Could not read the file: {e}")
    if c2.button("🧪 Load the sample template (demo data)", key="st_sample", disabled=not config.TEMPLATE_PATH.exists()):
        try:
            res = import_ledger_template(config.TEMPLATE_PATH)
            st.success(res.summary())
        except Exception as e:  # noqa: BLE001
            st.error(f"Import failed: {e}")

    pv = ss.get("st_tally_preview")
    if pv is None:
        return
    st.markdown(f"**Detected:** {pv.describe()}")
    for w in pv.warnings:
        st.warning(w)
    if pv.kind == "ledger_template":
        st.success("Imported directly (this format already carries groups, addresses and opening balances).")
        ss.pop("st_tally_preview", None)
        return
    if pv.kind == "unknown" or not (pv.ledgers or pv.items):
        if pv.kind != "unknown":
            st.warning("The file was recognised but contains no rows to import.")
        return

    if pv.kind == "ledger_list":
        _ledger_preview(pv)
    else:
        _item_preview(pv)
    if pv.skipped:
        with st.expander(f"Skipped lines ({len(pv.skipped)})"):
            st.write("\n".join(f"- {x}" for x in pv.skipped[:300]))


def _ledger_preview(pv: ti.ImportPreview) -> None:
    import pandas as pd

    st.caption("Tick the groups that are customers / suppliers. Expense, bank, tax and asset groups are "
               "unticked by default. Ledgers in unticked groups are not imported.")
    default = set(pv.default_party_groups())
    rows = [{"Import": g in default, "Group": g, "Ledgers": n, "Examples": ", ".join(pv.examples(g))}
            for g, n in pv.group_counts.items()]
    edited = st.data_editor(
        pd.DataFrame(rows), hide_index=True, width="stretch", key=f"st_groups_{pv.source_name}_{len(pv.ledgers)}",
        disabled=["Group", "Ledgers", "Examples"],
        column_config={"Import": st.column_config.CheckboxColumn("Import"),
                       "Examples": st.column_config.TextColumn("Examples", width="large")},
    )
    selected = [str(g) for g in edited.loc[edited["Import"] == True, "Group"].tolist()]  # noqa: E712
    n_sel = sum(pv.group_counts.get(g, 0) for g in selected)
    unknown_as = "Sundry Debtors"
    if ti.UNKNOWN_GROUP in selected:
        unknown_as = st.selectbox("Import '(group not detected)' ledgers as", ["Sundry Debtors", "Sundry Creditors"],
                                  key="st_unknown_as")
    st.caption(f"{n_sel:,} ledgers in {len(selected)} group(s) will be imported as parties.")
    if st.button(f"📤 Import {n_sel:,} parties", type="primary", disabled=not n_sel, key="st_apply_ledgers"):
        try:
            with st.spinner("Importing…"):
                added, updated = ti.apply_ledgers(pv, selected, unknown_group_as=unknown_as)
            st.session_state.pop("st_tally_preview", None)
            st.success(f"Parties: {added:,} added, {updated:,} updated.")
        except Exception as e:  # noqa: BLE001
            st.error(f"Import failed: {e}")


def _item_preview(pv: ti.ImportPreview) -> None:
    import pandas as pd

    rows = [{"Item": i.name, "Group": i.group or "", "Unit": i.unit or "", "Rate": i.rate} for i in pv.items]
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch", height=300)
    groups = pv.item_group_counts
    st.caption(f"{len(pv.items):,} items · groups: " + ", ".join(f"{g} ({n})" for g, n in list(groups.items())[:12])
               + (" …" if len(groups) > 12 else ""))
    if st.button(f"📤 Import {len(pv.items):,} items", type="primary", key="st_apply_items"):
        try:
            with st.spinner("Importing…"):
                added, updated = ti.apply_items(pv)
            st.session_state.pop("st_tally_preview", None)
            st.success(f"Items: {added:,} added, {updated:,} updated.")
        except Exception as e:  # noqa: BLE001
            st.error(f"Import failed: {e}")


# --------------------------------------------------------------------------- #
# Tally voucher export settings
# --------------------------------------------------------------------------- #
def _tally_settings_section() -> None:
    st.subheader("Tally voucher export settings")
    st.caption("Names must match your Tally company exactly (ledger names, voucher types, units). "
               "Used for the voucher XML / Excel / CSV files.")
    ts = tally_export.TallySettings.load()
    with st.form("tally_settings", border=True):
        c1, c2 = st.columns(2)
        company = c1.text_input("Tally company name (optional)", value=ts.company,
                                help="Leave blank to import into whichever company is open in Tally.")
        godown = c2.text_input("Godown / location (optional)", value=ts.godown,
                               help="Leave blank for Tally's default (Main Location).")
        c3, c4, c5, c6 = st.columns(4)
        sales_ledger = c3.text_input("Sales ledger", value=ts.sales_ledger)
        sales_vch = c4.text_input("Sales voucher type", value=ts.sales_vch_type)
        purchase_ledger = c5.text_input("Purchase ledger", value=ts.purchase_ledger)
        purchase_vch = c6.text_input("Purchase voucher type", value=ts.purchase_vch_type)
        c7, c8, c9, c10 = st.columns(4)
        inventory = c7.radio("Voucher content", ["With stock items", "Accounting only"],
                             index=0 if ts.inventory else 1,
                             help="Accounting only = party + sales/purchase ledger; item details go in the narration. "
                                  "Use it if you don't maintain stock items in Tally.")
        default_unit = c8.text_input("Unit when a line has none", value=ts.default_unit)
        weight_unit = c9.text_input("Unit for weight-priced lines", value=ts.weight_unit,
                                    help="Lines like '.52 × 5550' are exported as 0.52 of this unit at 5550 per unit.")
        stock_group = c10.text_input("Stock group for new items (optional)", value=ts.stock_group)
        if st.form_submit_button("💾 Save Tally settings", type="primary"):
            try:
                tally_export.TallySettings(
                    company=company, sales_ledger=sales_ledger or "Sales", purchase_ledger=purchase_ledger or "Purchase",
                    sales_vch_type=sales_vch or "Sales", purchase_vch_type=purchase_vch or "Purchase",
                    inventory=inventory == "With stock items", godown=godown, default_unit=default_unit or "Nos",
                    weight_unit=weight_unit or "Qtl", stock_group=stock_group,
                ).save()
                toast_ok("Tally settings saved.")
            except Exception as e:  # noqa: BLE001
                st.error(f"Could not save: {e}")
