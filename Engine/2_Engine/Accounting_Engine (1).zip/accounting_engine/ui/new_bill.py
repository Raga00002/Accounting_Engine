"""New Bill page: capture (photo / voice / typed) -> extract -> review -> save."""
from __future__ import annotations

import hashlib
from datetime import date
from pathlib import Path

import streamlit as st

from engine import config, db, extractor, service, speech, tally_export
from engine.extractor import ExtractionError
from engine.models import BillDraft, Party
from engine.speech import SpeechError
from engine.tally_import import canon_unit
from ui.common import ITEM_COLUMN_CONFIG, df_to_items, download_buttons, items_to_df, money, toast_ok

NEW_PARTY = "__new__"
PICK_OTHER = "__pick__"


# --------------------------------------------------------------------------- #
# session helpers
# --------------------------------------------------------------------------- #
def _init_state() -> None:
    ss = st.session_state
    ss.setdefault("nb_draft", None)
    ss.setdefault("nb_image", None)
    ss.setdefault("nb_items_df", None)  # editor base data – frozen for the life of one draft
    ss.setdefault("nb_version", 0)
    # Uploaded bills waiting to be processed: list of (name, bytes). Kept here because the
    # file_uploader widget loses its files as soon as it is not rendered (review stage).
    ss.setdefault("nb_queue", [])
    ss.setdefault("nb_seen_fps", {})  # (name, size) fingerprint -> uploader version it was queued under
    ss.setdefault("nb_transcript", "")
    ss.setdefault("nb_match_cache", {})


def _start_review(draft: BillDraft, image: tuple[bytes, str] | None) -> None:
    ss = st.session_state
    service.normalise_items(draft.items)
    ss.nb_draft = draft
    ss.nb_image = image
    # The data_editor must receive the *same* base frame on every rerun. Feeding the edited result
    # back in changes the widget identity each time and silently drops every second edit.
    ss.nb_items_df = items_to_df(draft.items)
    ss.nb_version += 1
    ss.pop("nb_quick_export", None)  # the previous bill's Tally-files offer ends when the next draft starts
    st.rerun()


def _reset() -> None:
    ss = st.session_state
    ss.nb_draft = None
    ss.nb_image = None
    ss.nb_items_df = None
    ss.nb_match_cache = {}
    ss.nb_item_cache = {}
    ss.nb_version += 1


def _dequeue(name: str, data: bytes | None = None) -> None:
    ss = st.session_state
    keep = []
    for n, d in ss.nb_queue:
        if n == name and (data is None or d == data):
            ss.nb_seen_fps.pop((n, len(d)), None)
            continue
        keep.append((n, d))
    ss.nb_queue = keep


def _extract_image(data: bytes, name: str) -> None:
    parties, items = service.known_names()
    with st.spinner("Reading the bill with Claude…"):
        draft = extractor.extract_from_image(data, name, parties, items, mock_key=Path(name).stem)
    _start_review(draft, (data, name))


def _extract_text(text: str, source: str) -> None:
    parties, items = service.known_names()
    with st.spinner("Understanding the bill…"):
        draft = extractor.extract_from_text(text, parties, items, source=source)
    _start_review(draft, None)


# --------------------------------------------------------------------------- #
# stage 1: input
# --------------------------------------------------------------------------- #
def _input_stage() -> None:
    if config.EXTRACTOR_MODE == "mock":
        st.info("Extractor is in **mock** mode (AE_EXTRACTOR_MODE=mock) – sample bills return canned results. "
                "Set AE_EXTRACTOR_MODE=live and ANTHROPIC_API_KEY in .env for real reading.", icon="🧪")
    elif not config.ANTHROPIC_API_KEY:
        st.warning("ANTHROPIC_API_KEY is not set – photo and voice reading will fail until you add it to .env. "
                   "Manual entry still works.", icon="🔑")

    tab_photo, tab_voice, tab_type = st.tabs(["📷 Photo / Upload", "🎤 Voice", "⌨️ Type / Manual"])

    with tab_photo:
        ss = st.session_state
        col_u, col_c = st.columns([3, 2])
        with col_u:
            files = st.file_uploader(
                "Bill photo(s) or PDF", type=["jpg", "jpeg", "png", "webp", "pdf"],
                accept_multiple_files=True, key=f"nb_upl_{ss.nb_version}",
                help="You can select several bills – they are processed one at a time.",
            )
        with col_c:
            use_cam = st.toggle("Use camera", value=False, key="nb_use_cam")
            # Keyed per draft: otherwise the photo just saved is still the widget's value when we come
            # back here and would be offered for reading a second time.
            shot = st.camera_input("Take a photo of the bill", key=f"nb_cam_{ss.nb_version}") if use_cam else None

        # Copy new uploads into the queue (the widget itself forgets them once we leave this stage).
        current_fps = {(f.name, f.size) for f in files or []}
        for f in files or []:
            fp = (f.name, f.size)
            if fp not in ss.nb_seen_fps:
                ss.nb_seen_fps[fp] = ss.nb_version
                ss.nb_queue.append((f.name, f.getvalue()))
        # A file the user removed from *this* uploader (its ✕) leaves the queue too. Files queued under
        # an earlier uploader instance (before a save/skip reset it) are kept – that is the queue's job.
        for fp, ver in list(ss.nb_seen_fps.items()):
            if ver == ss.nb_version and fp not in current_fps:
                ss.nb_queue = [(n, d) for n, d in ss.nb_queue if (n, len(d)) != fp]
                del ss.nb_seen_fps[fp]

        pending = ss.nb_queue
        chosen: tuple[str, bytes] | None = None
        if pending:
            if len(pending) > 1:
                labels = [f"{i + 1}. {n}" for i, (n, _) in enumerate(pending)]
                pick = st.selectbox("Bill to process next", range(len(pending)), format_func=lambda i: labels[i],
                                    key=f"nb_pick_file_{ss.nb_version}")
                if not isinstance(pick, int) or not 0 <= pick < len(pending):
                    pick = 0  # a keyed selectbox hands back its stale label once that file was removed (✕)
                chosen = pending[pick]
                st.caption(f"{len(pending)} bill(s) waiting.")
            else:
                chosen = pending[0]

        if shot is not None:
            src_name, data = "camera.jpg", shot.getvalue()
        elif chosen is not None:
            src_name, data = chosen
        else:
            src_name, data = None, b""
        if src_name is not None:
            if not src_name.lower().endswith(".pdf"):
                try:
                    st.image(data, caption=src_name, width=380)
                except Exception:  # noqa: BLE001 - preview failure must not block reading
                    st.caption(f"{src_name} ({len(data)/1024:.0f} KB) – preview not available")
            else:
                st.caption(f"PDF: {src_name} ({len(data)/1024:.0f} KB)")
            b_read, b_skip = st.columns([1, 1])
            if b_read.button("🔍 Read this bill", type="primary", key="nb_read_img"):
                try:
                    _extract_image(data, src_name)
                except ExtractionError as e:
                    st.error(str(e))
                except Exception as e:  # noqa: BLE001
                    st.error(f"Unexpected error while reading the bill: {e}")
            if shot is None and chosen is not None and b_skip.button("⏭️ Skip this file", key="nb_skip_img"):
                _dequeue(src_name, data)
                ss.nb_version += 1  # resets the uploader so the skipped file is not re-queued
                st.rerun()

    with tab_voice:
        lang_label = st.selectbox("Language", list(config.SPEECH_LANGUAGES), index=0, key="nb_lang")
        lang = config.SPEECH_LANGUAGES[lang_label]
        st.caption("Say it naturally, e.g. *\"Das Store, 5 bag BPT rice at 1540, 2 bag Sri rice 52 kilo at 5550 per quintal, bill number 13, today.\"*")
        try:
            from streamlit_mic_recorder import mic_recorder

            audio = mic_recorder(start_prompt="🎙️ Start recording", stop_prompt="⏹️ Stop", format="wav",
                                 just_once=True, use_container_width=False, key="nb_mic")
        except ImportError:
            audio = None
            st.warning("Microphone component not installed (pip install streamlit-mic-recorder). You can upload a WAV file instead.")
        if audio and audio.get("bytes"):
            try:
                st.session_state.nb_transcript = speech.transcribe(
                    audio["bytes"], audio.get("sample_rate", 16000), audio.get("sample_width", 2), lang
                )
                toast_ok("Transcribed – check the text below, then parse.")
            except SpeechError as e:
                st.error(str(e))
        up = st.file_uploader("…or upload a WAV / FLAC recording", type=["wav", "flac", "aiff"], key=f"nb_audio_{st.session_state.nb_version}")
        if up is not None and st.button("Transcribe file", key="nb_transcribe_file"):
            try:
                st.session_state.nb_transcript = speech.transcribe_file(up.getvalue(), lang)
            except SpeechError as e:
                st.error(str(e))
        transcript = st.text_area("Transcript (edit if needed)", key="nb_transcript", height=120)
        if st.button("🧠 Parse transcript into a bill", type="primary", key="nb_parse_voice", disabled=not (transcript or "").strip()):
            try:
                _extract_text(transcript, "voice")
            except ExtractionError as e:
                st.error(str(e))
            except Exception as e:  # noqa: BLE001
                st.error(f"Unexpected error while parsing the transcript: {e}")

    with tab_type:
        typed = st.text_area("Describe the bill in plain words", height=140, key="nb_typed",
                             placeholder="P. Roy – 20 bag RR rice 5.20 qtl @ 4090, 10 bag RR10 1.00 qtl @ 4290, 15 pkt mung dal 4.50 qtl @ 9550. Bill 02 dated 26-09-2026")
        c1, c2 = st.columns(2)
        if c1.button("🧠 Parse text into a bill", type="primary", key="nb_parse_text", disabled=not (typed or "").strip()):
            try:
                _extract_text(typed, "text")
            except ExtractionError as e:
                st.error(str(e))
            except Exception as e:  # noqa: BLE001
                st.error(f"Unexpected error while parsing the text: {e}")
        if c2.button("📝 Start a blank bill (manual entry)", key="nb_blank"):
            _start_review(BillDraft(source="manual", bill_date=date.today()), None)


# --------------------------------------------------------------------------- #
# stage 2: review
# --------------------------------------------------------------------------- #
def _party_section(draft: BillDraft, v: int) -> Party | None:
    st.subheader("1 · Party")
    # Fuzzy matching against every party runs on each rerun (every keystroke) – cache it per draft.
    cache = st.session_state.nb_match_cache
    ck = (v, draft.party_name_raw or "", db.parties_fingerprint())
    if ck not in cache:
        cache.clear()
        cache[ck] = service.resolve_party(draft)
    res = cache[ck]
    raw = draft.party_name_raw or ""
    options: list[str] = []
    labels: dict[str, str] = {}
    for c in res.candidates:
        key = str(c.party.id)
        options.append(key)
        via = f" (via alias “{c.matched_on}”)" if c.matched_on != c.party.name else ""
        labels[key] = f"{c.party.name} — {c.party.group_name}{via} · match {c.score:.0f}%"
    options.append(NEW_PARTY)
    labels[NEW_PARTY] = f"➕ New party: “{raw}”" if raw else "➕ New party"
    options.append(PICK_OTHER)
    labels[PICK_OTHER] = "🔍 Choose another existing party"

    # auto  -> pre-select the match; new -> pre-select "new party";
    # suggest -> no pre-selection: with thousands of ledgers there is nearly always *some*
    #            65%+ candidate, and a wrong pre-selection would book the bill to the wrong party.
    if res.kind == "auto":
        default_idx: int | None = 0
    elif res.kind == "new":
        default_idx = options.index(NEW_PARTY)
    else:
        default_idx = None
    if res.kind == "auto":
        st.success(f"Matched **{res.best.name}** from the database for “{raw}”.", icon="✅")
    elif res.kind == "suggest":
        st.warning(f"“{raw}” is not an exact match – please confirm the party.", icon="❓")
    elif raw:
        st.warning(f"“{raw}” is not in the database – add it below (it will be saved for next time).", icon="🆕")
    else:
        st.warning("No party name was found – choose or add one.", icon="❓")

    choice = st.radio("Party", options, index=default_idx, format_func=lambda k: labels[k], key=f"nb_party_{v}")
    if choice is None or choice not in labels:  # not in labels: stale label string after the options changed
        return None

    if choice == PICK_OTHER:
        parties = db.list_parties()
        if not parties:
            st.info("No parties in the database yet.")
            return None
        # dict, not a linear search per option: with 8,000 ledgers that was 64M steps (~1 s) per rerun
        by_id = {p.id: f"{p.name} — {p.group_name}" for p in parties}
        pid = st.selectbox("Existing party", list(by_id), key=f"nb_pick_party_{v}", index=None,
                           placeholder="Type to search…", format_func=lambda i: by_id.get(i, str(i)))
        if pid not in by_id:
            return None
        p = db.get_party(pid)
        _party_caption(p)
        return p

    if choice == NEW_PARTY:
        with st.container(border=True):
            c1, c2 = st.columns(2)
            name = c1.text_input("Party name *", value=raw, key=f"nb_np_name_{v}")
            group = c2.selectbox("Group", ["Sundry Debtors", "Sundry Creditors"],
                                 index=0 if service.default_group(draft.txn_type) == "Sundry Debtors" else 1,
                                 key=f"nb_np_group_{v}")
            address = st.text_area("Address (one line per row)", key=f"nb_np_addr_{v}", height=80)
            c3, c4, c5 = st.columns(3)
            state = c3.text_input("State", value=config.DEFAULT_STATE, key=f"nb_np_state_{v}")
            country = c4.text_input("Country", value=config.DEFAULT_COUNTRY, key=f"nb_np_country_{v}")
            pincode = c5.text_input("Pincode", key=f"nb_np_pin_{v}")
            c6, c7 = st.columns([2, 1])
            ob = c6.number_input("Opening balance (optional)", min_value=0.0, step=100.0, value=0.0, key=f"nb_np_ob_{v}")
            ob_drcr = c7.selectbox("Dr/Cr", ["Dr", "Cr"], index=0 if group == "Sundry Debtors" else 1, key=f"nb_np_obdc_{v}")
        if not name.strip():
            st.error("Party name is required.")
            return None
        existing = db.get_party_by_name(name)
        if existing:
            st.warning(f"“{existing.name}” already exists – it will be used (details above are ignored).")
            return existing
        return Party(name=name.strip(), group_name=group, address=address.strip() or None,
                     state=state.strip() or None, country=country.strip() or None, pincode=pincode.strip() or None,
                     opening_balance=ob if ob else None, opening_drcr=ob_drcr if ob else None)

    p = db.get_party(int(choice))
    _party_caption(p)
    return p


def _party_caption(p: Party | None) -> None:
    if not p:
        return
    bits = [p.group_name]
    if p.address:
        bits.append(p.address.replace("\n", ", "))
    if p.state:
        bits.append(p.state)
    if p.pincode:
        bits.append(str(p.pincode))
    if p.opening_balance is not None:
        bits.append(f"Opening {money(p.opening_balance)} {p.opening_drcr or ''}")
    st.caption(" · ".join(bits))


def _auto_number_cb(key: str) -> None:
    st.session_state[key] = db.next_bill_no(config.BILL_NO_PREFIX)


def _details_section(draft: BillDraft, v: int) -> tuple[date, str]:
    st.subheader("2 · Bill details")
    c1, c2, c3 = st.columns([1, 1, 1])
    with c1:
        d = st.date_input("Bill date *", value=draft.bill_date or date.today(), key=f"nb_date_{v}", format="DD/MM/YYYY")
        if draft.bill_date is None and draft.source != "manual":
            st.caption("⚠️ No date found on the bill – defaulted to today. Please confirm.")
    with c2:
        key = f"nb_billno_{v}"
        if key not in st.session_state:
            st.session_state[key] = draft.bill_no or ""
        bill_no = st.text_input("Bill number *", key=key)
        if not (draft.bill_no or "").strip() and draft.source != "manual":
            st.caption("⚠️ No bill number found on the bill.")
        st.button("Auto-number", key=f"nb_autonum_{v}", on_click=_auto_number_cb, args=(key,),
                  help=f"Next sequential number like {config.BILL_NO_PREFIX}/2026-27/001")
    with c3:
        txn = st.radio("Type", ["sale", "purchase"], index=0 if draft.txn_type == "sale" else 1, horizontal=True,
                       key=f"nb_txn_{v}", format_func=lambda s: "Sale (party owes us → Dr)" if s == "sale" else "Purchase (we owe party → Cr)")
        draft.txn_type = txn  # type: ignore[assignment]
    return d, bill_no


def _items_section(draft: BillDraft, v: int) -> None:
    st.subheader("3 · Items")
    st.caption("Fix anything the reader got wrong. Blank *Amount* is calculated as weight × rate (or qty × rate). Tick *Struck* for crossed-out lines.")
    ss = st.session_state
    if ss.nb_items_df is None:  # e.g. session restored mid-review
        ss.nb_items_df = items_to_df(draft.items)
    df = st.data_editor(
        ss.nb_items_df, num_rows="dynamic", width="stretch", hide_index=True,
        column_config=ITEM_COLUMN_CONFIG, key=f"nb_items_{v}",
    )
    draft.items = df_to_items(df)


ADD_NEW = "__add_new__"
USE_EXISTING = "__use_existing__"
UNITS = ["Bag", "Pkt", "Tin", "Kg", "Ltr", "Qtl", "Pcs", "Box", "Nos", "Set"]


def _item_check_section(draft: BillDraft, v: int) -> tuple[dict[str, dict], list[str]]:
    """Check every item description against the items master. Returns (decisions, unresolved names).

    known   -> shown as a tick, nothing to do
    suggest -> user picks a close match or 'add as new'
    new     -> user confirms 'add as new' (name/unit/group) or picks an existing item
    """
    st.subheader("3b · Item check")
    # Matching every line against the items master (8,000 items) costs ~0.4 s – cache per draft and
    # per set of item spellings, invalidated when the items table changes.
    cache = st.session_state.setdefault("nb_item_cache", {})
    # (struck-out lines are excluded: ticking 'Struck' must drop that line's question, not keep a stale answer)
    ck = (v, tuple(sorted({it.item.strip().lower() for it in draft.items if it.item.strip() and not it.struck_out})),
          db.items_fingerprint())
    if ck not in cache:
        cache.clear()
        cache[ck] = (service.resolve_items(draft), [i["name"] for i in db.list_items()])
    resolutions, all_names = cache[ck]
    decisions: dict[str, dict] = {}
    unresolved: list[str] = []
    if not resolutions:
        st.caption("No items yet.")
        return decisions, unresolved
    known = [r for r in resolutions if r.kind == "known"]
    todo = [r for r in resolutions if r.kind != "known"]
    if known:
        bits = [f"**{r.raw}**" + (f" → {r.canonical}" if r.canonical and r.canonical != r.raw else "") for r in known]
        st.success("Known items: " + " · ".join(bits), icon="✅")
        for r in known:
            decisions[r.raw] = {"action": "use", "name": r.canonical or r.raw}
    if not todo:
        return decisions, unresolved
    st.warning(f"{len(todo)} item description(s) are not in the items master – confirm each one:", icon="🆕")
    all_name_set = set(all_names)
    for r in todo:
        # Keyed by the spelling, not the position: editing another line in the items table must not
        # hand this item the radio choice made for a different one.
        # usedforsecurity=False: plain md5 raises on FIPS-enabled Windows machines
        key = f"nb_ic_{v}_{hashlib.md5(r.raw.lower().encode('utf-8'), usedforsecurity=False).hexdigest()[:12]}"
        with st.container(border=True):
            options: list[str] = [c[0] for c in r.candidates] + [ADD_NEW]
            if all_names:
                options.append(USE_EXISTING)
            labels = {c[0]: f"Use existing: {c[0]} · match {c[1]:.0f}%" for c in r.candidates}
            labels[ADD_NEW] = f"➕ Add “{r.raw}” as a NEW item"
            labels[USE_EXISTING] = "🔍 Use another existing item"
            title = f"“{r.raw}”" + (" – similar items found" if r.candidates else " – not in the items master")
            choice = st.radio(title, options, index=None, format_func=lambda k: labels[k], key=key)
            if choice is None or choice not in labels:  # a stale label string is not a choice
                unresolved.append(r.raw)
                continue
            if choice == ADD_NEW:
                c1, c2, c3 = st.columns([3, 1, 2])
                name = c1.text_input("Item name", value=r.raw, key=key + "_name")
                unit_opts = [None, *UNITS]
                seen_unit = canon_unit(r.unit)  # 'bag' / 'bags' on the bill -> 'Bag'
                u_idx = unit_opts.index(seen_unit) if seen_unit in unit_opts else 0
                unit = c2.selectbox("Unit", unit_opts, index=u_idx, key=key + "_unit",
                                    format_func=lambda u: "—" if u is None else u)
                group = c3.text_input("Stock group (optional)", key=key + "_group")
                if not name.strip():
                    unresolved.append(r.raw)
                    continue
                existing = db.get_item_by_name_or_alias(name)
                if existing:
                    st.caption(f"“{existing['name']}” already exists – it will be used.")
                    decisions[r.raw] = {"action": "use", "name": existing["name"]}
                else:
                    decisions[r.raw] = {"action": "new", "name": name.strip(), "unit": unit, "group": group.strip() or None}
            elif choice == USE_EXISTING:
                pick = st.selectbox("Existing item", all_names, index=None, key=key + "_pick",
                                    placeholder="Type to search…")
                if pick is None or pick not in all_name_set:
                    unresolved.append(r.raw)
                    continue
                decisions[r.raw] = {"action": "use", "name": pick}
            else:
                decisions[r.raw] = {"action": "use", "name": choice}
    return decisions, unresolved


def _totals_section(draft: BillDraft, check: BillDraft, rep, v: int) -> float | None:
    st.subheader("4 · Totals & checks")
    active = check.active_items
    if active:
        st.caption("Line amounts: " + " · ".join(
            f"{it.item} {money(it.effective_amount)}" for it in active))
    c1, c2, c3 = st.columns(3)
    c1.metric("Sum of lines", money(rep.computed_total))
    # max(0, …): a negative total from the reader would otherwise raise StreamlitValueBelowMinError.
    tw = c2.number_input("Total written on bill", min_value=0.0, step=1.0,
                         value=max(0.0, float(draft.total_written)) if draft.total_written is not None else 0.0,
                         key=f"nb_tw_{v}")
    draft.total_written = tw if tw > 0 else None
    book = rep.computed_total
    if draft.total_written is not None and rep.computed_total is not None and abs(draft.total_written - rep.computed_total) > config.AMOUNT_TOLERANCE:
        pick = c3.radio("Amount to book", ["Sum of lines", "Written total"], key=f"nb_book_{v}")
        book = rep.computed_total if pick == "Sum of lines" else draft.total_written
    elif rep.computed_total is None and draft.total_written is not None:
        book = draft.total_written
    c3.metric("Amount to book", money(book))

    for w in rep.warnings:
        st.warning(w, icon="⚠️")
    for m in rep.missing:
        st.error(m, icon="⛔")
    return book


def _review_stage() -> None:
    ss = st.session_state
    draft: BillDraft = ss.nb_draft
    v = ss.nb_version

    top_l, top_r = st.columns([3, 1])
    top_l.markdown(f"**Source:** {draft.source} · **Party on bill:** {draft.party_name_raw or '—'}")
    if top_r.button("✖ Discard & start over", key="nb_discard"):
        _reset()
        st.rerun()

    if ss.nb_image:
        left, right = st.columns([3, 2])
        with right:
            data, name = ss.nb_image
            if name.lower().endswith(".pdf"):
                st.caption(f"PDF: {name}")
            else:
                try:
                    st.image(data, caption=name, width="stretch")
                except Exception:  # noqa: BLE001
                    st.caption(f"{name} – preview not available")
    else:
        left = st.container()
    with left:
        party = _party_section(draft, v)
        bill_date, bill_no = _details_section(draft, v)

    # items + totals use the full width (the editor has many columns)
    _items_section(draft, v)
    item_decisions, unresolved_items = _item_check_section(draft, v)
    # Validate against the widget values (date / bill no may have been supplied by the user).
    # Deep copy: the editor keeps showing the user's own values; computed amounts are shown below.
    check = draft.model_copy(deep=True, update={"bill_date": bill_date, "bill_no": bill_no or None})
    rep = service.draft_to_review(check, party_resolved=party is not None, require_bill_no=False)
    if not bill_no.strip():
        rep.missing.append("Bill number is missing.")
    elif party is not None and party.id and db.bill_no_exists(party.id, bill_no):
        rep.missing.append(f"Bill number “{bill_no}” already exists for {party.name}.")
    for nm in unresolved_items:
        rep.missing.append(f"Item “{nm}”: pick an existing item or confirm it as new (section 3b).")
    book_amount = _totals_section(draft, check, rep, v)
    can_save = party is not None and not rep.missing and book_amount is not None

    st.divider()
    if st.button("💾 Save bill", type="primary", disabled=not can_save, key=f"nb_save_{v}"):
        try:
            bill = service.commit_bill(draft, party, bill_date, bill_no, book_amount, image=ss.nb_image,
                                       item_decisions=item_decisions)
        except ValueError as e:
            st.error(str(e))
        except Exception as e:  # noqa: BLE001
            st.error(f"Could not save: {e}")
        else:
            if ss.nb_image:
                _dequeue(ss.nb_image[1], ss.nb_image[0])
            _reset()
            ss["nb_last_saved"] = f"Saved bill {bill.bill_no} for {party.name} – {money(bill.amount)} {bill.drcr}"
            ss["nb_quick_export"] = bill.id  # offer Tally files for this bill until the next one starts
            st.rerun()

    with st.expander("What the reader saw (raw transcription & notes)"):
        if draft.notes:
            for n in draft.notes:
                st.markdown(f"- {n}")
        st.code(draft.raw_text or "(none)")


def _quick_export_block(bill_id: int) -> None:
    """Tally files for the bill that was just saved – one click, no trip to the Export page."""
    cache = st.session_state.setdefault("nb_quick_export_cache", {})
    try:
        ts = tally_export.TallySettings.load()
    except Exception as e:  # noqa: BLE001
        st.warning(f"Could not read the Tally settings: {e}")
        return
    # Look the bill up every run (cheap): the offer must vanish once the bill was deleted on the
    # Export page or the database was restored, instead of serving the cached files.
    bill = db.get_bill(bill_id)
    if bill is None or bill.bill_no != cache.get("no", bill.bill_no):
        cache.clear()
    if bill is None:
        st.session_state.pop("nb_quick_export", None)
        return
    # rebuild for a new bill *and* when the Tally settings were edited in the meantime
    if cache.get("id") != bill_id or cache.get("settings") != ts:
        try:
            bundle = tally_export.build_bundle([bill], list(tally_export.FORMATS), s=ts, stem=f"Bill_{_slug(bill.bill_no)}")
        except Exception as e:  # noqa: BLE001
            st.warning(f"Could not prepare the Tally files: {e}")
            return
        cache.clear()
        cache.update({"id": bill_id, "settings": ts, "files": bundle.files, "warnings": bundle.warnings, "no": bill.bill_no})
    with st.container(border=True):
        c1, c2 = st.columns([5, 1])
        c1.markdown(f"**Send bill {cache['no']} to Tally** – voucher XML (Import → Transactions), Excel, CSV, and the masters XML "
                    "in case the ledger / stock items don't exist in Tally yet.")
        if c2.button("Dismiss", key="nb_qe_dismiss"):
            st.session_state.pop("nb_quick_export", None)
            st.rerun()
        for w in cache["warnings"]:
            st.warning(w)
        download_buttons(cache["files"], key_prefix=f"nb_qe_{bill_id}", zip_name=f"Bill_{_slug(cache['no'])}_tally.zip")


def _slug(s: str) -> str:
    import re

    return re.sub(r"[^A-Za-z0-9._-]+", "_", s or "").strip("_") or "bill"


# --------------------------------------------------------------------------- #
def render() -> None:
    _init_state()
    st.title("📄 New Bill")
    # Always render this slot so the element tree below it (tabs) keeps a stable position;
    # otherwise the tab selection jumps back to the first tab when the banner disappears.
    with st.container():
        if st.session_state.get("nb_last_saved"):
            st.success(st.session_state.pop("nb_last_saved"), icon="✅")
        if st.session_state.nb_draft is None and st.session_state.get("nb_quick_export"):
            _quick_export_block(int(st.session_state["nb_quick_export"]))
    if st.session_state.nb_draft is None:
        _input_stage()
    else:
        _review_stage()
