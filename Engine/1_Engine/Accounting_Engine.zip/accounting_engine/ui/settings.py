"""Settings & Import page."""
from __future__ import annotations

import io
import sqlite3
from datetime import datetime

import streamlit as st

from engine import config, db
from engine.importer import import_ledger_template
from ui.common import toast_ok


def render() -> None:
    st.title("⚙️ Settings & Import")

    s = db.stats()
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Parties", s["parties"])
    c2.metric("Bills", s["bills"])
    c3.metric("Not exported", s["unexported"])
    c4.metric("Items", s["items"])

    st.subheader("AI reader")
    key_ok = bool(config.ANTHROPIC_API_KEY)
    st.markdown(
        f"- Mode: **{config.EXTRACTOR_MODE}**\n"
        f"- Model: `{config.CLAUDE_MODEL}` (fallbacks: {', '.join(config.CLAUDE_FALLBACK_MODELS)})\n"
        f"- API key: {'✅ set (…' + config.ANTHROPIC_API_KEY[-4:] + ')' if key_ok else '❌ missing'}\n"
        f"- Database: `{config.DB_PATH}`\n"
        f"- Bill images: `{config.BILL_IMAGE_DIR}` · Exports: `{config.EXPORT_DIR}`"
    )
    st.caption("Change these in the `.env` file next to app.py and restart the app.")

    st.subheader("Import Tally ledger file")
    st.caption("Upload a 'Ledgers in Default Template' workbook exported from Tally (or the sample template) "
               "to load parties, addresses and opening balances. Existing parties are updated, never duplicated.")
    up = st.file_uploader("Ledger workbook (.xlsx)", type=["xlsx"], key="st_import")
    i1, i2 = st.columns(2)
    imp_bills = i1.checkbox("Also import the bills listed in the file", value=True, key="st_imp_bills")
    mark_exp = i2.checkbox("Mark imported bills as already exported", value=True, key="st_imp_mark",
                           help="They are already in Tally, so they should not be exported again.")
    b1, b2 = st.columns(2)
    if b1.button("📤 Import uploaded file", type="primary", disabled=up is None, key="st_do_import"):
        try:
            res = import_ledger_template(io.BytesIO(up.getvalue()), import_bills=imp_bills, mark_bills_exported=mark_exp)
            st.success(res.summary())
            for w in res.warnings:
                st.warning(w)
        except Exception as e:  # noqa: BLE001
            st.error(f"Import failed: {e}")
    if b2.button("🧪 Load the sample template (demo data)", key="st_sample", disabled=not config.TEMPLATE_PATH.exists()):
        try:
            res = import_ledger_template(config.TEMPLATE_PATH, import_bills=imp_bills, mark_bills_exported=mark_exp)
            st.success(res.summary())
        except Exception as e:  # noqa: BLE001
            st.error(f"Import failed: {e}")

    st.subheader("Backup")
    if config.DB_PATH.exists():
        # SQLite's backup API – a plain file copy can miss data still in the -wal file.
        try:
            st.download_button("⬇️ Download database backup (.db)", data=db.backup_bytes(),
                               file_name=f"accounting_{datetime.now():%Y%m%d_%H%M}.db", key="st_backup")
        except Exception as e:  # noqa: BLE001
            st.error(f"Backup not available: {e}")
    restore = st.file_uploader("Restore database from a backup (.db) – replaces current data!", type=["db"], key="st_restore")
    if restore is not None:
        sure = st.checkbox("Yes, replace the current database with this backup", key="st_restore_sure")
        if st.button("♻️ Restore", disabled=not sure, key="st_do_restore"):
            data = restore.getvalue()
            if data[:16] != b"SQLite format 3\x00":
                st.error("That file is not a SQLite database.")
            else:
                try:
                    _restore_database(data)
                except Exception as e:  # noqa: BLE001
                    st.error(f"Restore failed – the current database was left unchanged: {e}")
                else:
                    st.rerun()


def _restore_database(data: bytes) -> None:
    """Replace the live database with ``data`` after validating it, keeping a backup of the old one."""
    # 1. Validate the upload on a scratch copy before touching anything.
    scratch = config.DB_PATH.with_name(f".restore_check_{datetime.now():%Y%m%d_%H%M%S}.db")
    scratch.write_bytes(data)
    try:
        chk = sqlite3.connect(str(scratch))
        try:
            if chk.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("the backup file is corrupt (integrity check failed)")
            tables = {r[0] for r in chk.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not {"parties", "bills"} <= tables:
                raise ValueError("the file is a SQLite database but not an Accounting Engine backup")
        finally:
            chk.close()  # Windows: the file cannot be deleted while a connection holds it
    finally:
        try:
            scratch.unlink()
        except OSError:
            pass
    # 2. Keep the current database (WAL content included).
    bak = None
    if config.DB_PATH.exists():
        bak = config.DB_PATH.with_name(f"{config.DB_PATH.stem}.before_restore_{datetime.now():%Y%m%d_%H%M%S}.db")
        db.backup_to(bak)
    # 3. Swap. Stale -wal/-shm files belong to the old database and must go first.
    for suffix in ("-wal", "-shm"):
        p = config.DB_PATH.with_name(config.DB_PATH.name + suffix)
        if p.exists():
            p.unlink()
    config.DB_PATH.write_bytes(data)
    db.init_db()
    toast_ok("Restored." + (f" Previous database kept at {bak.name}" if bak else ""))
