# Accounting Engine — bill photo / voice → Tally ledger Excel

A local web app for **Wings Industries**: photograph (or dictate) a handwritten kachha bill,
let Claude read it, confirm the party and any missing details, and get an Excel file in
Tally Prime's **"Ledgers in Default Template"** layout — plus a party/item database that
learns as you go.

```
photo / voice / typed text
        │
        ▼
 Claude extraction  ──►  party fuzzy-match against DB  ──►  review screen
 (items, qty, weight,     (auto / confirm / add new,         (fix anything, add date &
  rate, amount, total)     alias remembered)                  bill no., arithmetic checks)
        │                                                             │
        ▼                                                             ▼
   SQLite database  (parties · bills · line items · items master)   Save
        │
        ▼
 Excel export: sheet "Ledger" (exact Tally template) + sheet "Items" (line items)
```

## 1 · Install (Windows)

1. Install **Python 3.11 or newer** from python.org (tick *"Add python.exe to PATH"*).
2. Unzip / copy this folder anywhere, e.g. `Documents\Accounting_Engine`.
3. Double-click **`run.bat`**. The first run creates a virtual environment, installs the
   packages and opens `.env` in Notepad.
4. Paste your Anthropic API key into `.env`:
   ```
   ANTHROPIC_API_KEY=sk-ant-...
   AE_EXTRACTOR_MODE=live
   ```
   (keys: <https://console.anthropic.com>). Save, close Notepad, double-click `run.bat` again.
5. The app opens in your browser at <http://localhost:8501>. Phones on the same Wi-Fi can use
   the *Network URL* printed in the black window (camera + mic need Chrome/Edge; on a phone
   allow the browser to use the camera).

Mac/Linux: `./run.sh`.

## 2 · First-time setup inside the app

* **⚙️ Settings & Import → Import Tally ledger file** – upload the ledger workbook exported from
  Tally (same format as `fixtures/Ledgers_in_Default_Template.xlsx`). Parties, groups, addresses
  and opening balances are loaded; bills already in the file are marked *exported*.
* Or click **Load the sample template** to try with demo data.

## 3 · Daily use

### 📄 New Bill
| Tab | What to do |
|---|---|
| **📷 Photo / Upload** | Upload one or many bill photos (JPG/PNG/WEBP/PDF) or toggle *Use camera*. Click **Read this bill**. |
| **🎤 Voice** | Pick the language (English-India, Hindi, Assamese, Bengali), press *Start recording*, dictate, press *Stop*. Check the transcript, click **Parse transcript**. You can also upload a WAV file. |
| **⌨️ Type / Manual** | Type the bill in plain words, or start a blank bill and fill the table by hand. |

Then the **review screen**:

1. **Party** – shows *Matched ✅* (known party), *confirm ❓* (close spelling – pick the right one
   or add new), or *not in database 🆕* (fill group/address/state/pincode once; it is saved and the
   spelling on the bill is remembered as an alias so next time it auto-matches).
2. **Bill details** – date (defaults to today if not on the bill – confirm), bill number (type it
   or click *Auto-number* → `WI/2026-27/001`), Sale (Dr) / Purchase (Cr).
3. **Items** – editable table: item, qty, unit, weight (quintal), rate, amount, struck-out, note.
   Blank amount = weight × rate (or qty × rate). Crossed-out lines stay visible but are excluded.
4. **Totals & checks** – sum of lines vs total written on the bill; mismatches and missing data are
   flagged. Choose which amount to book if they differ. **Save bill**.

### 📚 Bills & Export
Filter by date / party / not-yet-exported, tick the bills, choose options
(opening balances, addresses, Items sheet, mark as exported) → **Build Excel file** → download.
The file is also saved under `data/exports/`.

**In Tally Prime:** Gateway of Tally → Import → Masters → *Ledgers* → choose the downloaded file
(Excel format, default template). Untick *Include opening balances* if the ledgers already exist
in Tally with balances.

### 👥 Parties · 📦 Items
Edit names, groups, addresses, opening balances and aliases; merge spellings via aliases.

## 4 · Where things live

| | |
|---|---|
| Database | `data/accounting.db` (SQLite – back it up from Settings) |
| Bill images | `data/bill_images/` |
| Excel exports | `data/exports/` |
| Settings | `.env` (see `.env.example`: business name, default state, bill prefix, model, data folder) |

## 5 · Reading conventions Claude is told about

* `5 Bg Rice (BPT) 5 x 1540 7700` → 5 bags priced per bag.
* `2 Bg Rice (Sri) .52 x 5550 2886` → 2 bags, 0.52 quintal × ₹5550/qtl.
* Struck lines are listed with *Struck* ticked and excluded from the total.
* The small printed page number (13, 32, 02 …) is **not** used as the bill number.
* Dates are never guessed – you are asked.
* Known party and item spellings from your database are passed to Claude so it prefers them.

## 6 · Development

```
pip install -r requirements.txt
python -m pytest -q tests          # 45 tests (DB, importer, matcher, validator, extractor, exporter, speech)
AE_EXTRACTOR_MODE=mock streamlit run app.py   # offline demo: sample bills return canned readings
```

Layout: `engine/` (pure logic, no Streamlit) · `ui/` (pages) · `app.py` (navigation) ·
`fixtures/` (Tally template, 5 sample bills, mock extractions) · `tests/`.
See `ROADMAP.md` for the build plan, decisions and what is next.
