#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
# (Re)install packages if a previous install was interrupted.
.venv/bin/python -c "import streamlit, anthropic, openpyxl, rapidfuzz, pydantic" 2>/dev/null || .venv/bin/pip install -r requirements.txt
[ -f .env ] || { cp .env.example .env; echo "Created .env – add your ANTHROPIC_API_KEY and re-run."; exit 1; }
export STREAMLIT_SERVER_SHOW_EMAIL_PROMPT=false
export STREAMLIT_BROWSER_GATHER_USAGE_STATS=false
exec .venv/bin/python -m streamlit run app.py
